#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Sinh các trang HTML của website SH1PP từ một bộ khung chung (header/footer/SEO).
Chạy:  python3 build.py   ->  ghi vào public/
Sửa nội dung ở file này rồi chạy lại để cập nhật toàn bộ trang."""
import json, os, datetime

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "public")
SITE = "https://sh1pp-website.web.app"   # ĐỔI thành tên miền thật khi triển khai
NAME = "Nhà máy Nhiệt điện Sông Hậu 1"
TODAY = datetime.date.today().isoformat()

NAV = [("index.html", "Trang chủ"), ("gioi-thieu.html", "Giới thiệu"), ("cong-nghe.html", "Công nghệ"),
       ("van-hanh.html", "Vận hành"), ("an-toan-moi-truong.html", "An toàn – Môi trường"),
       ("cong-dong.html", "Cộng đồng"), ("tin-tuc.html", "Tin tức"), ("thu-vien.html", "Thư viện"),
       ("lien-he.html", "Liên hệ")]

BOLT = ('<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">'
        '<path d="M13 2L4.5 13.5H11L10 22l8.5-11.5H12L13 2z" fill="#fff"/></svg>')

def ico(path):
    return ('<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#1F6FD1" stroke-width="1.8" '
            'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + path + '</svg>')

I_BOLT = ico('<path d="M13 2L4.5 13.5H11L10 22l8.5-11.5H12L13 2z"/>')
I_LEAF = ico('<path d="M5 19c0-8 5-13 14-14 0 9-5 14-13 14"/><path d="M5 19c3-5 6-8 10-10"/>')
I_SHIELD = ico('<path d="M12 3l7 3v5c0 5-3 8-7 10-4-2-7-5-7-10V6l7-3z"/><path d="M9 12l2 2 4-4"/>')
I_PEOPLE = ico('<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 20c0-4 3-6 6-6s6 2 6 6"/><path d="M15 14c3 0 6 1.5 6 5"/>')
I_FLAME = ico('<path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3 2-4 0 2 1 3 2 3 0-4-1-6 1-9z"/>')
I_GEAR = ico('<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>')
I_PIN = ico('<path d="M12 21s7-6 7-12a7 7 0 0 0-14 0c0 6 7 12 7 12z"/><circle cx="12" cy="9" r="2.5"/>')
I_PHONE = ico('<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>')
I_MAIL = ico('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>')
I_CLOCK = ico('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>')

def header(active):
    links = "".join(
        '<a href="%s"%s>%s</a>' % (h, ' class="active" aria-current="page"' if h == active else "", t) for h, t in NAV)
    solid = "" if active == "index.html" else " always-solid"
    return f'''<a class="skip" href="#main">Bỏ qua điều hướng</a>
<header class="site-header{solid}">
  <div class="header-top" aria-label="Thông tin nhanh"><div class="container header-top-in">
    <span><i class="dot"></i>Trung tâm Điện lực Sông Hậu · Chi nhánh Phát điện Dầu khí (PVPGB)</span>
    <span>2 × 600 MW · Vận hành thương mại từ 06/05/2022</span>
  </div></div>
  <div class="container nav-wrap">
    <a class="brand" href="index.html" aria-label="{NAME} - Trang chủ">
      <span class="brand-logo"><img src="assets/img/logo-sh1pp.png" srcset="assets/img/logo-sh1pp-sm.png 180w, assets/img/logo-sh1pp.png 360w" sizes="56px" width="58" height="48" alt="Logo Petrovietnam SH1PP"></span>
      <span class="brand-text"><span class="b1">Nhà máy Nhiệt điện</span><span class="b2">Sông Hậu 1</span></span>
    </a>
    <button class="nav-toggle" aria-label="Mở menu" aria-expanded="false" aria-controls="nav"><span></span></button>
    <nav class="nav" id="nav" aria-label="Điều hướng chính">{links}</nav>
  </div>
  <i class="scroll-progress" aria-hidden="true"></i>
</header>'''

def footer():
    quick = "".join('<li><a href="%s">%s</a></li>' % (h, t) for h, t in NAV[1:6])
    more = "".join('<li><a href="%s">%s</a></li>' % (h, t) for h, t in NAV[6:])
    return f'''<footer class="site-footer">
  <div class="container">
    <div class="foot-grid">
      <div>
        <a class="brand" href="index.html"><span class="brand-logo"><img src="assets/img/logo-sh1pp.png" width="58" height="48" alt="Logo Petrovietnam SH1PP" loading="lazy"></span><span class="brand-text"><span class="b1">Nhà máy Nhiệt điện</span><span class="b2">Sông Hậu 1</span></span></a>
        <p style="margin-top:14px">{NAME} – Trung tâm Điện lực Sông Hậu, 2 × 600 MW, góp phần bảo đảm an ninh năng lượng khu vực Tây Nam Bộ.</p>
      </div>
      <div><h4>Khám phá</h4><ul>{quick}</ul></div>
      <div><h4>Thông tin</h4><ul>{more}<li><a href="sitemap.xml">Sơ đồ trang</a></li></ul></div>
      <div><h4>Liên hệ</h4>
        <ul><li>Ấp Phú Xuân, Châu Thành, TP Cần Thơ</li>
        <li>Điện thoại: [cập nhật số chính thức]</li>
        <li>Email: [cập nhật địa chỉ chính thức]</li></ul>
      </div>
    </div>
    <div class="foot-bottom">
      <span>© {datetime.date.today().year} {NAME}. Nội dung đang chờ Ban Giám đốc và PVPGB duyệt trước khi công bố.</span>
      <span>Ảnh minh họa chỉ mang tính tham khảo. Logo và nhãn hiệu Petrovietnam thuộc quyền sở hữu của Petrovietnam.</span>
    </div>
  </div>
</footer>
<button class="to-top" aria-label="Lên đầu trang">↑</button>'''

SCRIPTS = '''<script src="assets/js/vendor/gsap.min.js" defer></script>
<script src="assets/js/vendor/ScrollTrigger.min.js" defer></script>
<script src="assets/js/vendor/countUp.umd.js" defer></script>
%s<script src="assets/js/main.js" defer></script>'''

def page(slug, title, desc, body, extra_head="", swiper=False, crumb=None, hero_h1=None, hero_p=None, hero_html=None,
         jsonld=None):
    url = f"{SITE}/{slug}" if slug != "index.html" else f"{SITE}/"
    if hero_html is None:
        hero_html = f'''<section class="page-hero"><div class="container">
  <div class="crumbs"><a href="index.html">Trang chủ</a> / {crumb or hero_h1}</div>
  <h1>{hero_h1}</h1><p>{hero_p or ""}</p></div></section>'''
    ld = ""
    if jsonld:
        ld = '<script type="application/ld+json">' + json.dumps(jsonld, ensure_ascii=False) + "</script>"
    sw = '<script src="assets/js/vendor/swiper-bundle.min.js" defer></script>\n' if swiper else ""
    swcss = '<link rel="stylesheet" href="assets/css/swiper-bundle.min.css">' if swiper else ""
    html = f'''<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<link rel="canonical" href="{url}">
<meta name="theme-color" content="#0B2E59">
<meta property="og:type" content="website"><meta property="og:locale" content="vi_VN">
<meta property="og:title" content="{title}"><meta property="og:description" content="{desc}">
<meta property="og:url" content="{url}"><meta property="og:image" content="{SITE}/assets/img/og-image.jpg">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="assets/img/favicon.png" type="image/png" sizes="64x64">
<link rel="apple-touch-icon" href="assets/img/apple-touch-icon.png">
<link rel="preload" href="fonts/be-vietnam-pro-vietnamese-700-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="fonts/montserrat-vietnamese-800-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="assets/css/main.css">
{swcss}
{extra_head}
{ld}
</head>
<body>
{header(slug)}
<main id="main">
{hero_html}
{body}
</main>
{footer()}
{SCRIPTS % sw}
</body>
</html>
'''
    with open(os.path.join(OUT, slug), "w", encoding="utf-8") as f:
        f.write(html)

# ----------------------------------------------------------------- TRANG CHỦ
SILHOUETTE = '''<svg class="hero-silhouette" viewBox="0 0 1440 260" preserveAspectRatio="xMidYMax slice" aria-hidden="true">
<defs><linearGradient id="sg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0d2a44"/><stop offset="1" stop-color="#050d16"/></linearGradient></defs>
<path fill="url(#sg)" d="M0 260V210h90v-30h60v30h80v-50h70v50h60v-70h20v-90h22v90h20v70h90v-40h110v-60h70v60h80v-30h90v30h60v-80h70v80h110v-40h90v40h60v-60h40v60h110V260z"/>
<g fill="#0a2036"><rect x="780" y="40" width="26" height="220"/><rect x="1070" y="20" width="28" height="240"/></g>
<g stroke="#FFB020" stroke-width="3" opacity=".9"><path d="M793 40v-8M1084 20v-8"/></g>
<g fill="#FFB020" opacity=".85"><circle cx="793" cy="30" r="3"/><circle cx="1084" cy="10" r="3"/></g>
<g stroke="#2a5a8a" stroke-width="2" fill="none" opacity=".8"><path d="M1180 260l30-150 30 150M1195 190h30M1200 150h20"/><path d="M1210 110L1290 120 1380 110"/></g>
</svg>'''

def home():
    HERO_PHOTO = ("<div class=\"hero-photo\" style=\"background-image:url('assets/img/hero.jpg')\"></div>"
                  if os.path.exists(os.path.join(OUT, "assets/img/hero.jpg")) else "")
    hero = f'''<section class="hero" id="top">
  <div class="hero-bg"></div>
  {HERO_PHOTO}
  <canvas id="spark-canvas" aria-hidden="true"></canvas>
  {SILHOUETTE}
  <div class="container"><div class="hero-inner">
    <div class="hero-badge"><i></i> Vận hành thương mại từ 06/05/2022</div>
    <p class="hero-kicker ln">Trung tâm Điện lực Sông Hậu</p>
    <h1><span class="ln h-pre">Nhà máy Nhiệt điện</span><span class="ln h-main">Sông Hậu 1</span></h1>
    <p class="hero-tag ln"><span>1.200 MW</span> cho Đồng bằng sông Cửu Long</p>
    <p class="lead ln">Hai tổ máy 600 MW, lò hơi than phun thông số siêu tới hạn, hệ thống xử lý khói thải hiện đại – góp phần bảo đảm an ninh năng lượng khu vực Tây Nam Bộ.</p>
    <div class="hero-actions ln">
      <a class="btn btn-primary" href="cong-nghe.html">Khám phá công nghệ →</a>
      <a class="btn btn-ghost" href="tin-tuc.html">Tin tức mới</a>
    </div>
  </div></div>
  <div class="scroll-cue" aria-hidden="true"><span>Cuộn xuống</span><i></i></div>
</section>
<section class="stats"><div class="container">
  <div class="stats-grid" role="list">
    <div class="stat" role="listitem"><div class="num"><span data-count="1200" data-stat="capacity_mw">1.200</span><small>MW</small></div><div class="lbl">Tổng công suất (2 × 600 MW)</div></div>
    <div class="stat" role="listitem"><div class="num"><span data-count="2" data-stat="units">2</span></div><div class="lbl">Tổ máy phát điện</div></div>
    <div class="stat" role="listitem"><div class="num"><span data-count="210" data-stat="stack_m">210</span><small>m</small></div><div class="lbl">Chiều cao ống khói</div></div>
    <div class="stat" role="listitem"><div class="num"><span data-count="20" data-stat="cumulative_bkwh">20</span><small>tỷ kWh</small></div><div class="lbl">Sản lượng lũy kế (mốc <span data-stat-text="cumulative_asof">25/11/2025</span>)</div></div>
    <div class="stat" role="listitem"><div class="num"><span data-count="7.8" data-dec="1" data-stat="design_bkwh">7,8</span><small>tỷ kWh</small></div><div class="lbl">Sản lượng thiết kế mỗi năm</div></div>
    <div class="stat" role="listitem"><div class="num"><span data-count="115.2" data-dec="1" data-stat="area_ha">115,2</span><small>ha</small></div><div class="lbl">Diện tích nhà máy</div></div>
  </div>
  <p class="stats-note">Số liệu theo thông cáo của Petrovietnam/PVPGB và báo chí; được cập nhật trong tệp data/stats.json.</p>
</div></section>'''

    body = '''
<section class="section">
  <div class="container grid-2">
    <div class="reveal">
      <span class="eyebrow">Giới thiệu</span>
      <h2>Nguồn điện nền quan trọng của khu vực Tây Nam Bộ</h2>
      <p class="lead">Nhà máy Nhiệt điện Sông Hậu 1 thuộc Trung tâm Điện lực Sông Hậu, do Tập đoàn Công nghiệp – Năng lượng Quốc gia Việt Nam (Petrovietnam) làm chủ đầu tư; Chi nhánh Phát điện Dầu khí (PVPGB) quản lý vận hành từ ngày 01/07/2023.</p>
      <ul class="check">
        <li>Công suất 1.200 MW, mỗi tổ máy gồm 01 lò hơi, 01 tuabin, 01 máy phát.</li>
        <li>Đấu nối lưới điện 500 kV qua đường dây 500 kV Sông Hậu – Đức Hòa.</li>
        <li>Tổng thầu EPC: LILAMA; thiết bị chính do Doosan (Hàn Quốc) cung cấp.</li>
      </ul>
      <a class="btn btn-primary" href="gioi-thieu.html">Tìm hiểu thêm →</a>
    </div>
    <figure class="figure reveal" style="margin:0">
      <div class="ph" role="img" aria-label="Vị trí đặt ảnh toàn cảnh nhà máy"><div><b>Ảnh toàn cảnh nhà máy</b>Đặt tệp assets/img/toan-canh.jpg (ảnh do nhà máy chụp hoặc flycam đã được duyệt)</div></div>
    </figure>
  </div>
</section>

<section class="section dark process" id="cong-nghe">
  <div class="container">
    <span class="eyebrow">Công nghệ</span>
    <h2 class="reveal">Từ than nhập khẩu đến điện năng 500 kV</h2>
    <p class="lead reveal">Sơ đồ khối tổng quát của một nhà máy nhiệt điện than siêu tới hạn. Rê chuột (hoặc chạm) vào từng bước để xem mô tả; dòng năng lượng tự chạy qua các khối.</p>
    <div class="process-svg-wrap reveal">
      <svg id="process-svg" class="process-svg" viewBox="0 0 1000 330" role="img" aria-label="Sơ đồ khối quy trình công nghệ nhà máy nhiệt điện than">
        <path id="flow-main" class="flow-line" d="M86,95 H1000" style="display:none"/>
        <path class="flow-line" d="M86,95 H914"/>
        <path id="flow-pulse" class="flow-pulse" d="M86,95 H914"/>
        <path class="flow-line" d="M370,95 V225 H410" stroke-dasharray="6 6"/>
        <path class="flow-line" d="M520,260 H545M655,260 H680" stroke-dasharray="6 6"/>
        <g class="node" transform="translate(30,60)"><rect width="112" height="70" rx="12"/><text x="56" y="30" text-anchor="middle">Cảng &amp;</text><text x="56" y="48" text-anchor="middle">kho than</text></g>
        <g class="node" transform="translate(165,60)"><rect width="112" height="70" rx="12"/><text x="56" y="30" text-anchor="middle">Cấp &amp;</text><text x="56" y="48" text-anchor="middle">nghiền than</text></g>
        <g class="node" transform="translate(300,60)"><rect width="112" height="70" rx="12"/><text x="56" y="30" text-anchor="middle">Lò hơi</text><text class="sub" x="56" y="50" text-anchor="middle">siêu tới hạn</text></g>
        <g class="node" transform="translate(435,60)"><rect width="112" height="70" rx="12"/><text x="56" y="30" text-anchor="middle">Tuabin</text><text class="sub" x="56" y="50" text-anchor="middle">ngưng hơi</text></g>
        <g class="node" transform="translate(570,60)"><rect width="112" height="70" rx="12"/><text x="56" y="30" text-anchor="middle">Máy phát</text><text class="sub" x="56" y="50" text-anchor="middle">600 MW/tổ</text></g>
        <g class="node" transform="translate(705,60)"><rect width="112" height="70" rx="12"/><text x="56" y="30" text-anchor="middle">Máy biến áp</text><text class="sub" x="56" y="50" text-anchor="middle">tăng áp</text></g>
        <g class="node" transform="translate(840,60)"><rect width="112" height="70" rx="12"/><text x="56" y="30" text-anchor="middle">Lưới điện</text><text class="sub" x="56" y="50" text-anchor="middle">500 kV</text></g>
        <text x="30" y="195" fill="#9fd9c2" font-family="Be Vietnam Pro,sans-serif" font-size="13" font-weight="700" letter-spacing="1.5">XỬ LÝ KHÓI THẢI</text>
        <g class="node2"><rect x="410" y="225" width="110" height="70" rx="12" fill="#0f2740" stroke="#19A974" stroke-width="1.5"/><text x="465" y="255" text-anchor="middle" fill="#e6eef7" font-family="Be Vietnam Pro,sans-serif" font-weight="700" font-size="15">Lọc bụi</text><text x="465" y="274" text-anchor="middle" fill="#9fb3c8" font-family="Be Vietnam Pro,sans-serif" font-size="11.5">tĩnh điện ESP</text></g>
        <g class="node2"><rect x="545" y="225" width="110" height="70" rx="12" fill="#0f2740" stroke="#19A974" stroke-width="1.5"/><text x="600" y="255" text-anchor="middle" fill="#e6eef7" font-family="Be Vietnam Pro,sans-serif" font-weight="700" font-size="15">Khử lưu</text><text x="600" y="274" text-anchor="middle" fill="#9fb3c8" font-family="Be Vietnam Pro,sans-serif" font-size="11.5">huỳnh FGD</text></g>
        <g class="node2"><rect x="680" y="225" width="110" height="70" rx="12" fill="#0f2740" stroke="#19A974" stroke-width="1.5"/><text x="735" y="255" text-anchor="middle" fill="#e6eef7" font-family="Be Vietnam Pro,sans-serif" font-weight="700" font-size="15">Ống khói</text><text x="735" y="274" text-anchor="middle" fill="#9fb3c8" font-family="Be Vietnam Pro,sans-serif" font-size="11.5">cao 210 m</text></g>
      </svg>
    </div>
    <div class="steps" role="list">
      <button class="step" role="listitem"><span class="n">1</span><b>Cảng &amp; kho than</b>Than nhập khẩu được chuyển tải về cảng nhà máy; chuyến than đầu tiên về ngày 01/03/2021.</button>
      <button class="step" role="listitem"><span class="n">2</span><b>Cấp &amp; nghiền than</b>Than được vận chuyển, nghiền mịn để phun vào lò hơi (than phun).</button>
      <button class="step" role="listitem"><span class="n">3</span><b>Lò hơi siêu tới hạn</b>Lò hơi trực lưu, quá nhiệt trung gian một lần, vòi đốt giảm phát thải NOx.</button>
      <button class="step" role="listitem"><span class="n">4</span><b>Tuabin hơi</b>Tuabin ngưng hơi, quá nhiệt trung gian một cấp, có trích hơi gia nhiệt nước cấp.</button>
      <button class="step" role="listitem"><span class="n">5</span><b>Máy phát</b>Mỗi tổ máy 600 MW; tổ máy 1 hòa đồng bộ ngày 26/11/2020, tổ máy 2 ngày 27/01/2021.</button>
      <button class="step" role="listitem"><span class="n">6</span><b>Máy biến áp</b>Nâng điện áp để truyền tải đi xa.</button>
      <button class="step" role="listitem"><span class="n">7</span><b>Lưới 500 kV</b>Đường dây 500 kV Sông Hậu – Đức Hòa, 2 mạch, dài 133 km.</button>
    </div>
    <p style="margin-top:24px"><a class="btn btn-ghost" href="cong-nghe.html">Xem chi tiết công nghệ →</a></p>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <span class="eyebrow">Lịch sử</span>
    <h2 class="reveal">Hành trình 2015 – 2026</h2>
    <div class="timeline">
      <div class="tl-item"><div class="tl-date">10/04/2015</div><p>Ký hợp đồng EPC giữa Petrovietnam và LILAMA.</p></div>
      <div class="tl-item"><div class="tl-date">16/05/2015</div><p>Khởi công xây dựng nhà máy.</p></div>
      <div class="tl-item"><div class="tl-date">28/07/2020</div><p>Đốt lửa lần đầu tổ máy 1.</p></div>
      <div class="tl-item"><div class="tl-date">26/11/2020</div><p>Tổ máy 1 hòa đồng bộ vào lưới điện 500 kV.</p></div>
      <div class="tl-item"><div class="tl-date">27/01/2021</div><p>Tổ máy 2 hòa đồng bộ lần đầu vào lưới điện quốc gia.</p></div>
      <div class="tl-item hl"><div class="tl-date">06/05/2022</div><p>Vận hành thương mại (COD) toàn nhà máy.</p></div>
      <div class="tl-item"><div class="tl-date">16/07/2022</div><p>Lễ khánh thành nhà máy.</p></div>
      <div class="tl-item"><div class="tl-date">01/07/2023</div><p>PVPGB tiếp nhận quản lý vận hành.</p></div>
      <div class="tl-item hl"><div class="tl-date">18/05/2024</div><p>Đạt mốc 10 tỷ kWh.</p></div>
      <div class="tl-item hl"><div class="tl-date">25/11/2025</div><p>Đạt mốc 20 tỷ kWh.</p></div>
      <div class="tl-item"><div class="tl-date">09/03/2026</div><p>Khánh thành khu nhà ở xã hội cho cán bộ, công nhân viên vận hành nhà máy.</p></div>
    </div>
    <p style="text-align:center"><a class="btn btn-primary" href="gioi-thieu.html#lich-su">Xem đầy đủ lịch sử →</a></p>
  </div>
</section>

<section class="section">
  <div class="container">
    <span class="eyebrow">Phát triển bền vững</span>
    <h2 class="reveal">Môi trường · An toàn · Cộng đồng</h2>
    <div class="cards stagger">
      <article class="card reveal-kid"><div class="ico">''' + I_LEAF + '''</div><h3>Môi trường</h3><p>Lọc bụi tĩnh điện, khử lưu huỳnh FGD, ống khói 210 m và các trạm quan trắc khí thải, nước thải tự động liên tục.</p><p style="margin-top:12px"><a href="an-toan-moi-truong.html">Xem chi tiết →</a></p></article>
      <article class="card reveal-kid"><div class="ico">''' + I_SHIELD + '''</div><h3>An toàn</h3><p>Phong trào thi đua “vận hành an toàn – hiệu quả” do Công đoàn Dầu khí Việt Nam, PVPGB và nhà máy phát động từ tháng 01/2024.</p><p style="margin-top:12px"><a href="an-toan-moi-truong.html#an-toan">Xem chi tiết →</a></p></article>
      <article class="card reveal-kid"><div class="ico">''' + I_PEOPLE + '''</div><h3>Cộng đồng</h3><p>Hoạt động an sinh xã hội hằng năm và khu nhà ở xã hội cho cán bộ, công nhân viên vận hành nhà máy.</p><p style="margin-top:12px"><a href="cong-dong.html">Xem chi tiết →</a></p></article>
    </div>
  </div>
</section>

<section class="section alt">
  <div class="container">
    <span class="eyebrow">Tin tức</span>
    <h2 class="reveal">Tin tức &amp; sự kiện</h2>
    <div class="swiper news-swiper reveal">
      <div class="swiper-wrapper">
''' + "".join(
        f'''        <div class="swiper-slide" style="height:auto"><article class="news-card"><div class="news-thumb">{I_BOLT.replace("#1F6FD1","#fff")}</div><div class="news-body"><div class="news-meta">{m}</div><h3>{t}</h3><p>{d}</p><a class="more" href="{u}" target="_blank" rel="noopener noreferrer">Đọc bài gốc →</a></div></article></div>\n'''
        for (m, t, d, u) in [
            ("18/05/2024", "Nhà máy chạm mốc sản lượng 10 tỷ kWh",
             "Cột mốc sản lượng đáng chú ý sau hơn hai năm vận hành thương mại.",
             "https://www.vietnamplus.vn/nha-may-nhiet-dien-song-hau-1-chinh-thuc-can-moc-san-luong-10-ty-kwh-post952136.vnp"),
            ("12/2024", "Lập kỷ lục phát điện trong ngày",
             "Sản lượng ngày đạt trên 27 triệu kWh, hệ số huy động trên 100%.",
             "https://petrovietnam.petrotimes.vn/nmnd-song-hau-1-lap-ky-luc-phat-dien-trong-ngay-720582.html"),
            ("Năm 2025", "Vượt kế hoạch sản lượng điện năm 2025",
             "Sản lượng ước đạt bằng 101,28% kế hoạch năm.",
             "https://petrovietnam.petrotimes.vn/nmnd-song-hau-1-vuot-ke-hoach-san-luong-dien-nam-2025-735776.html"),
            ("09/03/2026", "Khánh thành nhà ở xã hội cho CBCNV vận hành nhà máy",
             "Khu nhà ở xã hội do Petrovietnam làm chủ đầu tư.",
             "https://bnews.vn/khanh-thanh-nha-o-xa-hoi-danh-cho-can-bo-cong-nhan-vien-nha-may-nhiet-dien-song-hau-1/413457.html"),
        ]) + '''      </div>
      <div class="swiper-pagination"></div>
      <div class="swiper-button-prev" aria-label="Trước"></div><div class="swiper-button-next" aria-label="Sau"></div>
    </div>
    <p style="text-align:center"><a class="btn btn-primary" href="tin-tuc.html">Tất cả tin tức →</a></p>
  </div>
</section>

<section class="section">
  <div class="container grid-2">
    <div class="reveal">
      <span class="eyebrow">Liên hệ</span>
      <h2>Vị trí nhà máy</h2>
      <ul class="contact-list">
        <li><span class="ci">''' + I_PIN + '''</span><div><b>Địa chỉ</b>Ấp Phú Xuân, Châu Thành, TP Cần Thơ</div></li>
        <li><span class="ci">''' + I_PHONE + '''</span><div><b>Điện thoại</b>[cập nhật số chính thức]</div></li>
        <li><span class="ci">''' + I_MAIL + '''</span><div><b>Email</b>[cập nhật địa chỉ chính thức]</div></li>
      </ul>
      <a class="btn btn-primary" href="lien-he.html">Trang liên hệ →</a>
    </div>
    <div class="map-box reveal"><iframe title="Bản đồ vị trí nhà máy" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
      src="https://www.openstreetmap.org/export/embed.html?bbox=105.84%2C9.94%2C105.88%2C9.97&amp;layer=mapnik&amp;marker=9.95266%2C105.86071"></iframe></div>
  </div>
</section>'''
    ld = {"@context": "https://schema.org", "@type": "Organization", "name": NAME, "alternateName": "SH1PP",
          "url": SITE + "/", "logo": SITE + "/assets/img/logo-sh1pp.png", "parentOrganization": {"@type": "Organization", "name": "Petrovietnam"},
          "address": {"@type": "PostalAddress", "streetAddress": "Ấp Phú Xuân, Châu Thành",
                      "addressRegion": "Cần Thơ", "addressCountry": "VN"},
          "geo": {"@type": "GeoCoordinates", "latitude": 9.95266, "longitude": 105.86071}}
    page("index.html", f"{NAME} (SH1PP) – 1.200 MW | Petrovietnam",
         "Nhà máy Nhiệt điện Sông Hậu 1: 2 × 600 MW, lò hơi than phun siêu tới hạn, vận hành thương mại từ 06/05/2022. Giới thiệu, công nghệ, vận hành, tin tức.",
         body, swiper=True, hero_html=hero, jsonld=ld)

# ----------------------------------------------------------------- GIỚI THIỆU
def gioi_thieu():
    rows = [
        ("Tên", "Nhà máy Nhiệt điện Sông Hậu 1, thuộc Trung tâm Điện lực Sông Hậu"),
        ("Vị trí", "Ấp Phú Xuân, Châu Thành, TP Cần Thơ <span class='tag'>địa chỉ hành chính mới cần xác nhận</span>"),
        ("Diện tích", "115,2 ha"),
        ("Chủ đầu tư", "Tập đoàn Công nghiệp – Năng lượng Quốc gia Việt Nam (Petrovietnam; trước đây là Tập đoàn Dầu khí Việt Nam – PVN)"),
        ("Đơn vị quản lý vận hành", "Chi nhánh Phát điện Dầu khí (PVPGB), từ 01/07/2023"),
        ("Tổng thầu EPC", "Tổng công ty Lắp máy Việt Nam (LILAMA), hợp đồng ký ngày 10/04/2015"),
        ("Thiết bị chính", "Doosan (Hàn Quốc): lò hơi, tuabin, máy phát"),
        ("Công suất", "1.200 MW (2 × 600 MW)"),
        ("Tổng mức đầu tư", "Khoảng 43.043 tỷ đồng (khoảng 2,046 tỷ USD)"),
        ("Sản lượng thiết kế", "7,8 tỷ kWh/năm (điện năng sản xuất); Tmax khoảng 6.500 giờ/năm"),
        ("Nhiên liệu", "Than nhập khẩu (bitum/á bitum, nhiệt trị 5.500–6.100 kcal/kg); dầu FO/HFO dùng khởi động và đốt kèm"),
        ("Đấu nối", "Lưới 500 kV, đường dây 500 kV Sông Hậu – Đức Hòa dài 133 km, 2 mạch"),
    ]
    tbl = "".join(f"<tr><td>{a}</td><td>{b}</td></tr>" for a, b in rows)
    tl = [
        ("11/12/2013", "Quyết định 2414/QĐ-TTg cho phép áp dụng cơ chế đặc thù cho dự án điện cấp bách.", 0),
        ("10/04/2015", "Ký hợp đồng EPC giữa PVN và LILAMA; LILAMA ký hợp đồng thiết bị chính với Doosan.", 0),
        ("16/05/2015", "Lễ khởi công xây dựng nhà máy.", 0),
        ("20/04/2018", "Lắp đặt máy phát tổ máy 1 (khoảng 288 tấn).", 0),
        ("28/07/2020", "Đốt lửa lần đầu tổ máy 1.", 0),
        ("26/11/2020", "Tổ máy 1 hòa đồng bộ vào lưới điện 500 kV.", 0),
        ("27/01/2021", "Tổ máy 2 hòa đồng bộ lần đầu vào lưới điện quốc gia.", 0),
        ("01/03/2021", "Tiếp nhận lô than đầu tiên.", 0),
        ("12/04/2022", "Tổng thầu EPC bàn giao nhà máy cho chủ đầu tư.", 0),
        ("06/05/2022", "Vận hành thương mại (COD).", 1),
        ("16/07/2022", "Lễ khánh thành nhà máy.", 0),
        ("31/08/2022", "Đạt mốc 1 tỷ kWh thương mại.", 0),
        ("01/07/2023", "PVPGB tiếp nhận quản lý vận hành.", 0),
        ("18/05/2024", "Đạt mốc 10 tỷ kWh.", 1),
        ("13/11/2024", "Kỷ lục sản lượng ngày: 27,44 triệu kWh.", 0),
        ("02/12/2024", "Kỷ lục sản lượng ngày mới: 27,488 triệu kWh, hệ số huy động trên 100%.", 0),
        ("25/11/2025", "Đạt mốc 20 tỷ kWh.", 1),
        ("09/03/2026", "Khánh thành khu nhà ở xã hội cho cán bộ, công nhân viên vận hành nhà máy.", 0),
    ]
    tlh = "".join(f'<div class="tl-item{" hl" if h else ""}"><div class="tl-date">{d}</div><p>{t}</p></div>' for d, t, h in tl)
    body = f'''
<section class="section"><div class="container">
  <span class="eyebrow">Tổng quan</span><h2 class="reveal">Thông tin chung</h2>
  <p class="lead reveal">Nhà máy Nhiệt điện Sông Hậu 1 là dự án điện cấp bách do Petrovietnam làm chủ đầu tư, nằm trong Trung tâm Điện lực Sông Hậu, phục vụ nhu cầu điện của khu vực Tây Nam Bộ và hệ thống điện quốc gia.</p>
  <div class="table-wrap reveal" style="margin-top:28px"><table class="tbl"><tbody>{tbl}</tbody></table></div>
  <p class="notice" style="margin-top:20px">Một số thông số kỹ thuật (thông số hơi, model thiết bị, loại và hiệu suất hệ thống khử lưu huỳnh) chưa được công bố chính thức nên chưa đăng tại đây. Sẽ bổ sung sau khi được Ban Giám đốc phê duyệt.</p>
</div></section>
<section class="section alt" id="lich-su"><div class="container">
  <span class="eyebrow">Lịch sử</span><h2 class="reveal">Các mốc quan trọng</h2>
  <div class="timeline">{tlh}</div>
</div></section>
<section class="section"><div class="container">
  <span class="eyebrow">Tầm nhìn</span><h2>Định hướng</h2>
  <div class="cards stagger">
    <article class="card reveal-kid"><div class="ico">{I_BOLT}</div><h3>Vận hành an toàn, ổn định</h3><p>Bảo đảm cung cấp điện liên tục, an toàn cho người và thiết bị.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_LEAF}</div><h3>Thân thiện môi trường</h3><p>Kiểm soát phát thải theo quy định và quan trắc tự động liên tục.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_GEAR}</div><h3>Hiệu quả và hiện đại</h3><p>Rút ngắn thời gian bảo dưỡng, tối ưu chi phí và nâng cao độ sẵn sàng.</p></article>
  </div>
  <p class="notice" style="margin-top:24px">Mục tiêu nhiệm kỳ 2025–2030 của Đảng ủy nhà máy là 35 tỷ kWh trong 5 năm; đây là mục tiêu, không phải kết quả đã đạt.</p>
</div></section>'''
    page("gioi-thieu.html", f"Giới thiệu | {NAME}", "Thông tin chung, chủ đầu tư, tổng thầu, công suất và các mốc lịch sử của Nhà máy Nhiệt điện Sông Hậu 1 (2013–2026).",
         body, hero_h1="Giới thiệu", hero_p="Thông tin tổng quan và hành trình xây dựng, vận hành Nhà máy Nhiệt điện Sông Hậu 1.")

# ----------------------------------------------------------------- CÔNG NGHỆ
def cong_nghe():
    body = f'''
<section class="section"><div class="container">
  <span class="eyebrow">Công nghệ chính</span><h2 class="reveal">Tổ máy 2 × 600 MW siêu tới hạn</h2>
  <div class="cards stagger">
    <article class="card reveal-kid"><div class="ico">{I_FLAME}</div><h3>Lò hơi</h3><p>Than phun, thông số siêu tới hạn, trực lưu, đốt trực tiếp, quá nhiệt trung gian một lần; dùng vòi đốt giảm phát thải NOx (low-NOx burner).</p></article>
    <article class="card reveal-kid"><div class="ico">{I_GEAR}</div><h3>Tuabin</h3><p>Tuabin ngưng hơi truyền thống, quá nhiệt trung gian một cấp, trích hơi gia nhiệt nước cấp, thông số hơi đầu vào siêu tới hạn.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_BOLT}</div><h3>Máy phát &amp; đấu nối</h3><p>Mỗi tổ máy 600 MW; đấu nối lưới 500 kV qua đường dây Sông Hậu – Đức Hòa, 2 mạch, dài 133 km.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_LEAF}</div><h3>Xử lý khói thải</h3><p>Lọc bụi tĩnh điện (ESP), hệ thống khử lưu huỳnh (FGD) và ống khói cao 210 m.</p></article>
  </div>
</div></section>
<section class="section dark"><div class="container">
  <span class="eyebrow">Quy trình</span><h2 class="reveal">Quy trình sản xuất điện</h2>
  <div class="grid-2" style="align-items:start">
    <div class="reveal">
      <ol style="padding-left:20px;line-height:1.9">
        <li><b>Tiếp nhận than</b>: than nhập khẩu được chuyển tải từ tàu mẹ về cảng nhà máy rồi đưa vào kho than.</li>
        <li><b>Cấp và nghiền than</b>: than được vận chuyển, nghiền mịn để phun vào lò hơi.</li>
        <li><b>Sinh hơi</b>: nhiệt đốt than biến nước thành hơi ở thông số siêu tới hạn.</li>
        <li><b>Phát điện</b>: hơi làm quay tuabin nối với máy phát; hơi sau tuabin được ngưng tụ và tuần hoàn lại.</li>
        <li><b>Truyền tải</b>: điện được nâng áp qua máy biến áp và hòa vào lưới 500 kV.</li>
        <li><b>Xử lý khói thải</b>: khói qua ESP và FGD trước khi thoát ra ống khói 210 m.</li>
      </ol>
    </div>
    <div class="reveal"><div class="card"><h3>Hệ thống phụ trợ</h3><p>Kho than, cảng nhập than, cảng đá vôi, cửa nhận nước, kênh thải nước làm mát và hệ thống thải xỉ.</p></div>
      <div class="card" style="margin-top:16px"><h3>Quan trắc tự động</h3><p>Trạm quan trắc khí thải tự động liên tục, trạm quan trắc nước thải tự động liên tục và quan trắc nước làm mát.</p></div></div>
  </div>
</div></section>
<section class="section"><div class="container">
  <p class="notice">Các thông số chi tiết (áp suất, nhiệt độ hơi, model thiết bị, loại và hiệu suất FGD, tải trọng cảng) chưa được công bố chính thức nên chưa đăng. Theo quy định an ninh mạng, website không đăng sơ đồ P&amp;ID, thông số bảo vệ rơ-le hay sơ đồ mạng DCS/SCADA.</p>
</div></section>'''
    page("cong-nghe.html", f"Công nghệ | {NAME}", "Công nghệ lò hơi than phun siêu tới hạn, tuabin, máy phát, ESP, FGD và quy trình sản xuất điện tại Nhà máy Nhiệt điện Sông Hậu 1.",
         body, hero_h1="Công nghệ", hero_p="Lò hơi than phun siêu tới hạn, hệ thống xử lý khói thải và quy trình sản xuất điện.")

# ----------------------------------------------------------------- VẬN HÀNH
def van_hanh():
    rows = [
        ("2023", "Ước đạt 5,03 tỷ kWh; doanh thu khoảng 10.954 tỷ đồng"),
        ("2024", "Ước đạt 7.030 triệu kWh, hoàn thành kế hoạch năm sớm 64 ngày"),
        ("6 tháng đầu 2025", "3,72 tỷ kWh"),
        ("2025", "Ước đạt 6.216,19 triệu kWh (101,28% kế hoạch); doanh thu 11.302,35 tỷ đồng"),
    ]
    tbl = "".join(f"<tr><td>{a}</td><td>{b}</td></tr>" for a, b in rows)
    body = f'''
<section class="section"><div class="container">
  <span class="eyebrow">Sản lượng</span><h2 class="reveal">Mốc sản lượng &amp; kỷ lục</h2>
  <div class="cards stagger">
    <article class="card reveal-kid"><h3>10 tỷ kWh</h3><p>Đạt ngày 18/05/2024.</p></article>
    <article class="card reveal-kid"><h3>20 tỷ kWh</h3><p>Đạt ngày 25/11/2025.</p></article>
    <article class="card reveal-kid"><h3>27,488 triệu kWh/ngày</h3><p>Kỷ lục sản lượng ngày, ghi nhận ngày 02/12/2024.</p></article>
    <article class="card reveal-kid"><h3>13–14 ngày</h3><p>Thời gian tiểu tu mỗi tổ máy sau khi được rút ngắn.</p></article>
  </div>
  <h3 style="margin-top:44px">Kết quả theo năm</h3>
  <div class="table-wrap"><table class="tbl"><thead><tr><th>Kỳ</th><th>Kết quả</th></tr></thead><tbody>{tbl}</tbody></table></div>
  <p class="notice" style="margin-top:18px">Số liệu “ước đạt” cuối năm có thể khác số quyết toán; sẽ được thay bằng số liệu chính thức của PVPGB.</p>
</div></section>'''
    page("van-hanh.html", f"Vận hành | {NAME}", "Sản lượng điện, mốc 10 tỷ và 20 tỷ kWh, kỷ lục ngày và kết quả vận hành của Nhà máy Nhiệt điện Sông Hậu 1.",
         body, hero_h1="Vận hành", hero_p="Sản lượng, mốc kỷ lục và kết quả vận hành thương mại của nhà máy.")

# ----------------------------------------------------------------- AN TOÀN - MÔI TRƯỜNG
def an_toan():
    body = f'''
<section class="section" id="moi-truong"><div class="container grid-2">
  <div class="reveal"><span class="eyebrow">Môi trường</span><h2>Kiểm soát phát thải</h2>
    <ul class="check">
      <li>Lọc bụi tĩnh điện (ESP) xử lý bụi trong khói thải.</li>
      <li>Hệ thống khử lưu huỳnh (FGD) và ống khói cao 210 m.</li>
      <li>Trạm quan trắc khí thải và nước thải tự động liên tục.</li>
      <li>Quan trắc tự động nước làm mát.</li>
      <li>Xỉ được cung cấp làm phụ gia xi măng (hợp đồng triển khai từ năm 2020).</li>
    </ul>
    <p class="notice">Hiệu suất xử lý thực tế sẽ được đăng theo số liệu quan trắc chính thức sau khi được duyệt.</p></div>
  <div class="card reveal"><div class="ico">{I_LEAF}</div><h3>Cam kết</h3><p>Vận hành tuân thủ các quy chuẩn môi trường hiện hành và công khai kết quả quan trắc theo quy định.</p></div>
</div></section>
<section class="section alt" id="an-toan"><div class="container">
  <span class="eyebrow">An toàn</span><h2 class="reveal">An toàn lao động &amp; vận hành</h2>
  <div class="cards stagger">
    <article class="card reveal-kid"><div class="ico">{I_SHIELD}</div><h3>Thi đua an toàn – hiệu quả</h3><p>Phong trào do Công đoàn Dầu khí Việt Nam, PVPGB và nhà máy phát động từ tháng 01/2024.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_GEAR}</div><h3>Bảo dưỡng chủ động</h3><p>Thời gian tiểu tu được rút ngắn còn khoảng 13–14 ngày mỗi tổ máy.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_CLOCK}</div><h3>Độ sẵn sàng cao</h3><p>Hệ số huy động trên 100% trong ngày kỷ lục 02/12/2024.</p></article>
  </div>
</div></section>'''
    page("an-toan-moi-truong.html", f"An toàn – Môi trường | {NAME}", "Kiểm soát phát thải, quan trắc tự động và an toàn lao động tại Nhà máy Nhiệt điện Sông Hậu 1.",
         body, hero_h1="An toàn – Môi trường", crumb="An toàn – Môi trường", hero_p="Cam kết vận hành an toàn, thân thiện với môi trường.")

# ----------------------------------------------------------------- CỘNG ĐỒNG
def cong_dong():
    body = f'''
<section class="section"><div class="container">
  <span class="eyebrow">Cộng đồng</span><h2 class="reveal">Đồng hành cùng địa phương</h2>
  <div class="cards stagger">
    <article class="card reveal-kid"><div class="ico">{I_PEOPLE}</div><h3>An sinh xã hội</h3><p>Hằng năm thăm hỏi gia đình chính sách và hộ khó khăn dịp Tết, ngày Thương binh – Liệt sĩ; hỗ trợ học sinh mùa tựu trường; tổ chức Trung thu, Tết thiếu nhi.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_GEAR}</div><h3>Việc làm</h3><p>Nhà máy tạo việc làm cho lao động Hậu Giang, Cần Thơ, Vĩnh Long, Sóc Trăng.</p></article>
    <article class="card reveal-kid"><div class="ico">{I_PIN}</div><h3>Nhà ở xã hội CBCNV</h3><p>Khởi công 06/12/2024, khánh thành 09/03/2026; do Petrovietnam làm chủ đầu tư, tại ấp Phú Nhơn, xã Châu Thành.</p></article>
  </div>
</div></section>'''
    page("cong-dong.html", f"Cộng đồng | {NAME}", "Hoạt động an sinh xã hội, việc làm địa phương và khu nhà ở xã hội cho cán bộ, công nhân viên Nhà máy Nhiệt điện Sông Hậu 1.",
         body, hero_h1="Cộng đồng", hero_p="Trách nhiệm xã hội và đồng hành cùng địa phương.")

# ----------------------------------------------------------------- TIN TỨC
NEWS = [
    ("16/07/2022", "Khánh thành Nhà máy Nhiệt điện Sông Hậu 1 tại Hậu Giang", "Lễ khánh thành nhà máy có sự tham dự của Thủ tướng Chính phủ.",
     "https://www.vietnamplus.vn/khanh-thanh-nha-may-nhiet-dien-song-hau-1-tai-hau-giang-post806071.vnp"),
    ("18/05/2024", "Nhà máy chạm mốc sản lượng 10 tỷ kWh", "Cột mốc sản lượng sau hơn hai năm vận hành thương mại.",
     "https://www.vietnamplus.vn/nha-may-nhiet-dien-song-hau-1-chinh-thuc-can-moc-san-luong-10-ty-kwh-post952136.vnp"),
    ("01/2024", "Thi đua vận hành an toàn – hiệu quả tại Nhà máy Nhiệt điện Sông Hậu 1", "Phong trào thi đua do Công đoàn Dầu khí Việt Nam, PVPGB và nhà máy phát động.",
     "https://petrovietnam.petrotimes.vn/thi-dua-van-hanh-an-toan-hieu-qua-nha-may-nhiet-dien-song-hau-1-704401.html"),
    ("12/2024", "Nhà máy lập kỷ lục phát điện trong ngày", "Sản lượng ngày trên 27 triệu kWh, hệ số huy động trên 100%.",
     "https://petrovietnam.petrotimes.vn/nmnd-song-hau-1-lap-ky-luc-phat-dien-trong-ngay-720582.html"),
    ("Năm 2025", "Vượt kế hoạch sản lượng điện năm 2025", "Sản lượng ước đạt bằng 101,28% kế hoạch năm.",
     "https://petrovietnam.petrotimes.vn/nmnd-song-hau-1-vuot-ke-hoach-san-luong-dien-nam-2025-735776.html"),
    ("09/03/2026", "Khánh thành nhà ở xã hội cho CBCNV nhà máy", "Khu nhà ở xã hội do Petrovietnam làm chủ đầu tư.",
     "https://bnews.vn/khanh-thanh-nha-o-xa-hoi-danh-cho-can-bo-cong-nhan-vien-nha-may-nhiet-dien-song-hau-1/413457.html"),
]

def tin_tuc():
    cards = "".join(
        f'<article class="news-card reveal-kid"><div class="news-thumb">{I_BOLT.replace("#1F6FD1","#fff")}</div><div class="news-body"><div class="news-meta">{m}</div><h3>{t}</h3><p>{d}</p><a class="more" href="{u}" target="_blank" rel="noopener noreferrer">Đọc bài gốc →</a></div></article>'
        for m, t, d, u in NEWS)
    body = f'''
<section class="section"><div class="container">
  <p class="lead">Các bản tin dưới đây dẫn tới bài gốc trên báo chí và cổng thông tin của Petrovietnam. Ảnh và nội dung bài viết thuộc bản quyền của các đơn vị đăng tải.</p>
  <div class="cards stagger" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr))">{cards}</div>
</div></section>'''
    page("tin-tuc.html", f"Tin tức | {NAME}", "Tin tức và sự kiện về Nhà máy Nhiệt điện Sông Hậu 1: mốc sản lượng, kỷ lục, an toàn và cộng đồng.",
         body, hero_h1="Tin tức", hero_p="Tin tức và sự kiện nổi bật của nhà máy.")

# ----------------------------------------------------------------- THƯ VIỆN
def thu_vien():
    items = ["Toàn cảnh nhà máy", "Ống khói 210 m", "Gian tuabin", "Lò hơi", "Sân phân phối 500 kV", "Cảng than",
             "Hệ thống FGD", "Phòng điều khiển trung tâm"]
    g = "".join(f'<div class="ph reveal-kid" role="img" aria-label="Vị trí ảnh: {i}"><div><b>{i}</b>Ảnh do nhà máy cung cấp (chờ duyệt)</div></div>' for i in items)
    body = f'''
<section class="section"><div class="container">
  <p class="lead">Thư viện sẽ hiển thị ảnh và video flycam do nhà máy chụp, quay và được Ban Giám đốc duyệt. Các ô dưới đây là vị trí dự kiến.</p>
  <div class="gallery stagger">{g}</div>
  <p class="notice" style="margin-top:24px">Ảnh minh họa lấy từ Unsplash, Pexels hoặc Pixabay (nếu dùng) phải ghi rõ “ảnh minh họa”, không dùng để người xem hiểu là ảnh Sông Hậu 1.</p>
</div></section>'''
    page("thu-vien.html", f"Thư viện | {NAME}", "Thư viện ảnh và video nhà máy: toàn cảnh, ống khói, tuabin, lò hơi, sân phân phối 500 kV, cảng than.",
         body, hero_h1="Thư viện", hero_p="Hình ảnh và video về nhà máy.")

# ----------------------------------------------------------------- LIÊN HỆ
def lien_he():
    body = f'''
<section class="section"><div class="container grid-2">
  <div class="reveal">
    <ul class="contact-list">
      <li><span class="ci">{I_PIN}</span><div><b>Địa chỉ</b>Ấp Phú Xuân, Châu Thành, TP Cần Thơ</div></li>
      <li><span class="ci">{I_PHONE}</span><div><b>Điện thoại</b>[cập nhật số chính thức]</div></li>
      <li><span class="ci">{I_MAIL}</span><div><b>Email</b>[cập nhật địa chỉ chính thức]</div></li>
      <li><span class="ci">{I_CLOCK}</span><div><b>Giờ làm việc</b>[cập nhật]</div></li>
    </ul>
    <p class="notice">Số điện thoại, email, giờ làm việc và địa chỉ hành chính sau sáp nhập tỉnh cần được Phòng Tổ chức – Hành chính xác nhận trước khi công bố.</p>
  </div>
  <div class="map-box reveal"><iframe title="Bản đồ vị trí nhà máy" loading="lazy" referrerpolicy="no-referrer-when-downgrade"
    src="https://www.openstreetmap.org/export/embed.html?bbox=105.84%2C9.94%2C105.88%2C9.97&amp;layer=mapnik&amp;marker=9.95266%2C105.86071"></iframe></div>
</div></section>'''
    page("lien-he.html", f"Liên hệ | {NAME}", "Thông tin liên hệ và bản đồ vị trí Nhà máy Nhiệt điện Sông Hậu 1 tại Châu Thành, TP Cần Thơ.",
         body, hero_h1="Liên hệ", hero_p="Địa chỉ, điện thoại, email và bản đồ.")

# ----------------------------------------------------------------- 404, sitemap, robots
def misc():
    body = '''<section class="section"><div class="container" style="text-align:center;padding:40px 0">
<h2>Không tìm thấy trang</h2><p class="lead" style="margin:0 auto 24px">Trang bạn tìm không tồn tại hoặc đã được di chuyển.</p>
<a class="btn btn-primary" href="index.html">Về trang chủ</a></div></section>'''
    page("404.html", f"Không tìm thấy trang | {NAME}", "Trang không tồn tại.", body, hero_h1="404", hero_p="")
    urls = "".join(f"  <url><loc>{SITE}/{'' if h == 'index.html' else h}</loc><lastmod>{TODAY}</lastmod></url>\n" for h, _ in NAV)
    with open(os.path.join(OUT, "sitemap.xml"), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + urls + "</urlset>\n")
    with open(os.path.join(OUT, "robots.txt"), "w", encoding="utf-8") as f:
        f.write(f"User-agent: *\nAllow: /\nSitemap: {SITE}/sitemap.xml\n")

if __name__ == "__main__":
    os.makedirs(os.path.join(OUT, "assets/img"), exist_ok=True)
    home(); gioi_thieu(); cong_nghe(); van_hanh(); an_toan(); cong_dong(); tin_tuc(); thu_vien(); lien_he(); misc()
    print("Đã tạo:", ", ".join(sorted(f for f in os.listdir(OUT) if f.endswith((".html", ".xml", ".txt")))))
