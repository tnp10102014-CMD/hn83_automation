# Website Nhà máy Nhiệt điện Sông Hậu 1 (SH1PP)

## Xem thử trên máy
    cd public && python -m http.server 8000     # mở http://localhost:8000

## Triển khai Firebase Hosting
    npm i -g firebase-tools
    firebase login
    firebase init hosting      # chọn thư mục public, KHÔNG ghi đè index.html
    firebase deploy --only hosting
Xem thử trước khi công bố: `firebase hosting:channel:deploy preview`

## Việc cần anh bổ sung (đang để chỗ trống)
1. Logo: ĐÃ gắn (header, footer, favicon, ảnh chia sẻ). Bản gốc anh gửi: public/assets/img/logo-sh1pp-original.png. Nếu có bản PNG nền trong suốt hoặc SVG, thay vào để logo hiển thị trực tiếp trên nền tối.
2. Ảnh nền hero: đặt public/assets/img/hero.jpg (1920x1080, dưới 400 KB); web tự dùng khi có tệp (chạy lại build.py). og-image.jpg (1200x630) hiện đang là logo trên nền xanh; có ảnh nhà máy được duyệt thì thay.
3. Ảnh toàn cảnh và Thư viện: ảnh/flycam do nhà máy chụp, đã được Ban Giám đốc duyệt.
4. Điện thoại, email, giờ làm việc: sửa trong build.py (tìm "[cập nhật").
5. Đổi SITE trong build.py thành tên miền thật (ảnh hưởng canonical, sitemap).
6. Số liệu lũy kế: sửa public/data/stats.json, không cần sửa HTML.

## Sửa nội dung
Sửa build.py rồi chạy `python3 build.py` để sinh lại toàn bộ trang HTML.

## Phông chữ
Tiêu đề: Montserrat 600/700/800; nội dung: Be Vietnam Pro (SIL OFL, tự host trong public/fonts/, hỗ trợ đủ dấu tiếng Việt).
Tên nhà máy ở header sửa trong build.py (lớp b1, b2); chữ khổ lớn ở hero sửa trong hàm home().
