/* SH1PP website - hiệu ứng: GSAP/ScrollTrigger, CountUp, Swiper, tia điện Canvas, SVG dòng năng lượng */
(function () {
  "use strict";
  document.documentElement.classList.add("js");
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var hasGSAP = typeof window.gsap !== "undefined";
  if (hasGSAP && window.ScrollTrigger) gsap.registerPlugin(ScrollTrigger);

  /* ---------- Header + menu mobile ---------- */
  var header = $(".site-header");
  var toggle = $(".nav-toggle");
  function onScroll() {
    var y = window.scrollY || 0;
    if (header) {
      header.classList.toggle("solid", y > 40);
      var dh = document.documentElement.scrollHeight - window.innerHeight;
      header.style.setProperty("--p", dh > 0 ? Math.min(1, y / dh).toFixed(4) : 0);
    }
    var tt = $(".to-top");
    if (tt) tt.classList.toggle("show", y > 700);
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
  if (toggle) {
    toggle.addEventListener("click", function () {
      var open = document.body.classList.toggle("nav-open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
    $$(".nav a").forEach(function (a) {
      a.addEventListener("click", function () {
        document.body.classList.remove("nav-open");
        toggle.setAttribute("aria-expanded", "false");
      });
    });
  }
  var tt = $(".to-top");
  if (tt) tt.addEventListener("click", function () { window.scrollTo({ top: 0, behavior: reduce ? "auto" : "smooth" }); });

  /* ---------- Số liệu từ data/stats.json (nếu tải được) ---------- */
  function applyStats(data) {
    if (!data) return;
    $$("[data-stat]").forEach(function (el) {
      var k = el.getAttribute("data-stat");
      if (data[k] !== undefined) el.setAttribute("data-count", data[k]);
    });
    $$("[data-stat-text]").forEach(function (el) {
      var k = el.getAttribute("data-stat-text");
      if (data[k] !== undefined) el.textContent = data[k];
    });
  }
  function initCounters() {
    var CU = window.countUp && window.countUp.CountUp;
    $$("[data-count]").forEach(function (el) {
      var target = parseFloat(el.getAttribute("data-count"));
      var dec = parseInt(el.getAttribute("data-dec") || "0", 10);
      var holder = el.closest(".stat");
      function run() {
        if (el._done) return; el._done = true;
        if (holder) holder.classList.add("in");
        if (CU && !reduce) {
          new CU(el, target, { decimalPlaces: dec, duration: 2.2, separator: ".", decimal: "," }).start();
        } else {
          el.textContent = target.toLocaleString("vi-VN", { minimumFractionDigits: dec, maximumFractionDigits: dec });
        }
      }
      if ("IntersectionObserver" in window) {
        var io = new IntersectionObserver(function (es) {
          es.forEach(function (e) { if (e.isIntersecting) { run(); io.disconnect(); } });
        }, { threshold: 0.4 });
        io.observe(el);
      } else { run(); }
    });
  }
  if (window.fetch && location.protocol !== "file:") {
    fetch("data/stats.json", { cache: "no-cache" })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (d) { applyStats(d); initCounters(); })
      .catch(function () { initCounters(); });
  } else { initCounters(); }

  /* ---------- Reveal khi cuộn ---------- */
  if (hasGSAP && window.ScrollTrigger && !reduce) {
    $$(".reveal").forEach(function (el) {
      gsap.to(el, {
        opacity: 1, y: 0, duration: 0.8, ease: "power2.out",
        scrollTrigger: { trigger: el, start: "top 88%", once: true }
      });
    });
    $$(".stagger").forEach(function (wrap) {
      var kids = $$(".reveal-kid", wrap);
      if (!kids.length) return;
      gsap.set(kids, { opacity: 0, y: 28 });
      gsap.to(kids, {
        opacity: 1, y: 0, duration: 0.7, stagger: 0.1, ease: "power2.out",
        scrollTrigger: { trigger: wrap, start: "top 85%", once: true }
      });
    });
    /* Hero: chữ hiện từng dòng + parallax ảnh nền */
    var lines = $$(".hero .ln");
    if (lines.length) {
      gsap.from(lines, { y: 40, opacity: 0, duration: 0.9, stagger: 0.14, ease: "power3.out", delay: 0.15 });
    }
    var photo = $(".hero-photo");
    if (photo) {
      gsap.to(photo, {
        yPercent: 12, ease: "none",
        scrollTrigger: { trigger: ".hero", start: "top top", end: "bottom top", scrub: true }
      });
    }
    /* Timeline: dây tiến độ sáng dần */
    $$(".tl-item").forEach(function (it) {
      gsap.from(it, {
        opacity: 0, x: it.matches(":nth-child(even)") ? 40 : -40, duration: 0.8, ease: "power2.out",
        scrollTrigger: { trigger: it, start: "top 88%", once: true }
      });
    });
  } else {
    $$(".reveal,.reveal-kid").forEach(function (e) { e.style.opacity = 1; e.style.transform = "none"; });
  }

  /* ---------- Hiệu ứng tia điện (Canvas, < 80 hạt, chỉ desktop) ---------- */
  var cv = $("#spark-canvas");
  if (cv && !reduce && window.matchMedia("(min-width: 900px)").matches) {
    var ctx = cv.getContext("2d");
    var W, H, pts = [], N = 64, raf, visible = true;
    function size() {
      var r = cv.getBoundingClientRect(); var dpr = Math.min(window.devicePixelRatio || 1, 2);
      W = cv.width = r.width * dpr; H = cv.height = r.height * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      W = r.width; H = r.height;
    }
    function seed() {
      pts = [];
      for (var i = 0; i < N; i++) pts.push({ x: Math.random() * W, y: Math.random() * H, vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35, r: Math.random() * 1.6 + .6 });
    }
    function frame() {
      if (!visible) { raf = requestAnimationFrame(frame); return; }
      ctx.clearRect(0, 0, W, H);
      for (var i = 0; i < pts.length; i++) {
        var p = pts[i]; p.x += p.vx; p.y += p.vy;
        if (p.x < 0 || p.x > W) p.vx *= -1; if (p.y < 0 || p.y > H) p.vy *= -1;
        for (var j = i + 1; j < pts.length; j++) {
          var q = pts[j], dx = p.x - q.x, dy = p.y - q.y, d = dx * dx + dy * dy;
          if (d < 14000) {
            var a = (1 - d / 14000) * 0.35;
            ctx.strokeStyle = (i + j) % 7 === 0 ? "rgba(255,176,32," + a + ")" : "rgba(111,216,255," + a * .8 + ")";
            ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(q.x, q.y); ctx.stroke();
          }
        }
        ctx.fillStyle = "rgba(160,225,255,.85)"; ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, 6.283); ctx.fill();
      }
      raf = requestAnimationFrame(frame);
    }
    size(); seed(); frame();
    window.addEventListener("resize", function () { size(); seed(); });
    if ("IntersectionObserver" in window) {
      new IntersectionObserver(function (es) { visible = es[0].isIntersecting; }).observe(cv);
    }
  }

  /* ---------- Quy trình công nghệ: dòng năng lượng SVG ---------- */
  var proc = $("#process-svg");
  if (proc) {
    var nodes = $$(".node", proc);
    var steps = $$(".step");
    var path = $("#flow-main", proc);
    var pulse = $("#flow-pulse", proc);
    function setOn(i) {
      nodes.forEach(function (n, k) { n.classList.toggle("on", k === i); });
      steps.forEach(function (s, k) { s.classList.toggle("on", k === i); });
    }
    steps.forEach(function (s, i) {
      s.addEventListener("click", function () { setOn(i); });
      s.addEventListener("mouseenter", function () { setOn(i); });
    });
    nodes.forEach(function (n, i) { n.addEventListener("mouseenter", function () { setOn(i); }); });
    setOn(0);
    if (path && pulse && !reduce) {
      var len = path.getTotalLength();
      pulse.setAttribute("d", path.getAttribute("d"));
      pulse.style.strokeDasharray = "28 " + len;
      var t0 = null, active = true;
      function tick(ts) {
        if (!t0) t0 = ts;
        var prog = ((ts - t0) / 7000) % 1;
        pulse.style.strokeDashoffset = (-prog * (len + 28)) + "";
        var idx = Math.min(nodes.length - 1, Math.floor(prog * nodes.length));
        if (active && proc._auto) setOn(idx);
        requestAnimationFrame(tick);
      }
      proc._auto = true;
      proc.addEventListener("mouseenter", function () { proc._auto = false; });
      proc.addEventListener("mouseleave", function () { proc._auto = true; });
      $$(".step").forEach(function (s) {
        s.addEventListener("mouseenter", function () { proc._auto = false; });
        s.addEventListener("mouseleave", function () { proc._auto = true; });
      });
      requestAnimationFrame(tick);
    }
  }

  /* ---------- Swiper tin tức ---------- */
  if (window.Swiper && $(".news-swiper")) {
    new Swiper(".news-swiper", {
      slidesPerView: 1, spaceBetween: 20, loop: false, grabCursor: true,
      pagination: { el: ".swiper-pagination", clickable: true },
      navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" },
      breakpoints: { 700: { slidesPerView: 2 }, 1024: { slidesPerView: 3 } },
      autoplay: reduce ? false : undefined
    });
  }

  /* ---------- Đánh dấu menu đang xem ---------- */
  var cur = location.pathname.split("/").pop() || "index.html";
  $$(".nav a").forEach(function (a) {
    var h = a.getAttribute("href");
    if (h === cur || (cur === "" && h === "index.html")) a.classList.add("active");
  });
})();
